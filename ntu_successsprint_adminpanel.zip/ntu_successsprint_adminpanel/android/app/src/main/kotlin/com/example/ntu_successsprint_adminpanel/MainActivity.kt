package com.example.ntu_successsprint_adminpanel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
